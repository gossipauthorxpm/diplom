Версия 0.1
Автор - Сапожников Владислав Валерьевич

Для запуска приложения необходимо:
- Система семейства Windows
- Установленный python 3.11

pip install pythonnet

Запуск приложения:
1. Распакуйте архив по удобному вам пути
2. В корне откройте cmd 
3. Выполните команду - python -m venv venv
4. Выполните команду - python -m pip uninstall pythonnet
5. Выполните команду - python -m pip install pythonnet
6. Запустите файл start.bat